//Dalya William & Guy Rahamim

#pragma once
#include<iostream>
#include <cassert>
class Topping
{
private:

	//member variables
	char* name;
	float price;
	char coverage;

public:

	//constructors
	 Topping();
	 Topping(const char* name,  char coverage, float price = 10 );
	 Topping(const Topping& other);
	
	 //destructor
	 ~Topping();

	//Getters
	inline char* getName() const;
	inline float getPrice() const;
	inline char getCoverage() const;

	//Setters
	void setName(const char* name);
	void setPrice(float price);
	void setCoverage(const char coverage);

	//Operator overloaders
	void operator=(const Topping& other);
	friend std::ostream& operator<<(std::ostream& os, const Topping& other);
	friend bool operator>(const Topping& one, const Topping& other);
	friend bool operator<(const Topping& one, const Topping& other);
	friend bool operator==(const Topping& one, const Topping& other);
};

