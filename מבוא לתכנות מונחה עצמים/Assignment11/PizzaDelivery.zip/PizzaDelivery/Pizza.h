//Dalya William & Guy Rahamim

#pragma once
#include"Topping.h"
#include <iostream>
class Pizza 
{
private:

	//member variables
	char* type;
	float basePrice;
	int num_top;
	Topping* toppings;

public:

	//constructors
	Pizza(char* type, float basePrice, int num_top);
	Pizza(const Pizza& other);
	
	//destructor
	~Pizza();


	//getters
	Topping* getToppings();

	//setters
	void setType(char* type);
	void setBasePrice(float basePrice);
	void setNum_top(int num_top);
	void initToppings(int num_top);
	void copyToppings(int num_top, Topping* toppings);

	//class specific functions
	float calcPrice() const;

	//operator overrloaders
	Pizza& operator=(const Pizza& other);
	friend std::ostream& operator<<(std::ostream& os, const Pizza& other);
	friend void operator+(Pizza& one, const Topping& other);
	friend bool operator==(const Pizza& one, const Pizza& other);
};