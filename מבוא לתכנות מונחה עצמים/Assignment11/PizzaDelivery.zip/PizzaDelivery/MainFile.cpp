//Dalya William & Guy Rahamim

#include <iostream>
#include "Pizza.h"
#include "Topping.h"
#define MAX_LENGTH 200

Pizza initPizza();
Topping initTopping();

int main()
{
	//taking input for the first pizza
	std::cout << "Please enter details of pizza 1:" << std::endl;
	Pizza pizza1 = initPizza();

	//taking input for the second pizz
	std::cout << "\nPlease enter details of pizza 2:" << std::endl;
	Pizza pizza2 = initPizza();


	//printing first pizza
	std::cout<< "*********************Pizza 1******************" << std::endl;
	std::cout << "Pizza 1:\n" << pizza1 << std::endl << std::endl;

	//printing second pizza
	std::cout<< "*********************Pizza 2******************" << std::endl;
	std::cout << "Pizza 2:\n" << pizza2 << std::endl << std::endl;

	//creating new toppings for comparison operators
	Topping t1("olives", 'f', 3);
	Topping t2("tuna", 'f', 5);
	Topping t3("pineapple", 'f', 10);


	//comparisons
	std::cout << "*********************COMPARISONS******************" << std::endl;
	std::cout << "pizza1 == pizza2: " << ((pizza1 == pizza2)? "true":"false") << std::endl;
	std::cout << "t1 == t2: " << (t1 == t2 ? "true" : "false") << std::endl;
	std::cout << "t2 > t3: " << (t2 > t3 ? "true" : "false") << std::endl;
	std::cout << "t2 < t3: " << (t2 < t3 ? "true" : "false") << std::endl;
}

Pizza initPizza()
{
	//declaring variables for creating a pizza.
	Topping* toppings;
	char type[MAX_LENGTH];
	float baseprice = 25.f;
	int num_top;

	//asking for type and number of number of toppings
	std::cout << "What type of dough would you like? ";
	std::cin >> type;

	std::cout << "\nHow many toppings would you like? ";
	std::cin >> num_top;

	//creating a pizza.
	Pizza pizza(type, baseprice, num_top);


	//adding topping to pizza using initTopping function
	for (int i = 0; i < num_top; i++)
	{
		Topping tempTopping = initTopping();

 		pizza + tempTopping;
		
	}
	return pizza;
}


Topping initTopping()
{
	//declaring variables for creating a topping.
	char coverage;
	char name[MAX_LENGTH];
	float price =5.f;

	//asking for topping name and coverge.
	std::cout << "what topping would you like to add? ";
	std::cin >> name;

	std::cout << "\nWhat part of the pizza should the " << name << " cover?\n";
	std::cout << "l-left half \nr-right half \nf-the entire pizza" << std::endl;
	std::cin >> coverage;

	//creating the topping
	Topping top(name, coverage, price);
	return top;
}