//Dalya William & Guy Rahamim

#include "Topping.h"

Topping::Topping()
{
	this->name = NULL;
	setCoverage('f');
	setPrice(0);

}

Topping::Topping(const char* name, char coverage, float price)
{
	this->name = NULL;
	setName(name);
	setPrice(price);
	setCoverage(coverage);
}

Topping::Topping(const Topping& other)
{
	this->name = NULL;
	*this = other;
}

Topping::~Topping()
{
	delete[] (this->name);
}

char* Topping::getName() const
{
	return name;
}

float Topping::getPrice() const
{
	return price;
}

char Topping::getCoverage() const
{
	return coverage;
}

void Topping::setName(const char* newName)
{
	//if (name)
	//delete[] this->name;

	int newLength = strlen(newName);
	this->name = new char[newLength + 1];
	assert(name);
	strcpy_s(this->name, newLength + 1, newName);

}

void Topping::setPrice(float price)
{
	this->price = price;
}

void Topping::setCoverage(const char coverage)
{
	this->coverage = coverage;
}

void Topping::operator=(const Topping& other)
{
	if (name)
		delete[] this->name;

	setName(other.getName());
	setPrice(other.getPrice());
	setCoverage(other.getCoverage());
}

std::ostream& operator<<(std::ostream& os, const Topping& other)
{
	os << "Topping name: " << other.name << ", price: " << other.price << ", coverage: " << other.coverage;
	return os;
}

bool operator>(const Topping& one, const Topping& other)
{
	return (one.price > other.price);
}

bool operator<(const Topping& one, const Topping& other)
{
	return (one.price < other.price);
}

bool operator==(const Topping& one, const Topping& other)
{
	return (one.coverage == other.coverage);
}


