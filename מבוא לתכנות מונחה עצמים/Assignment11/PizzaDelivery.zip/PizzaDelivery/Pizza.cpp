//Dalya William & Guy Rahamim

#include "Pizza.h"

Pizza::Pizza(char* type, float basePrice, int num_top)
{
	this->type = NULL;
	this->toppings = NULL;

	setType(type);
	setBasePrice(basePrice);
	setNum_top(num_top);
	initToppings(num_top);
}

Pizza::Pizza(const Pizza& other)
{
	this->type = NULL;
	this->toppings = NULL;
	*this = other;
}

Pizza::~Pizza()
{
	delete[] type;
	delete[] toppings;
}

Topping* Pizza::getToppings()
{
	return toppings;
}

void Pizza::setType(char* type)
{
	delete[] this->type;
	int newLength = strlen(type);

	this->type = new char[newLength + 1];
	assert(type);

	strcpy_s(this->type, newLength + 1, type);
}

void Pizza::setBasePrice(float basePrice)
{
	this->basePrice = basePrice;
}

void Pizza::setNum_top(int num_top)
{
	this->num_top = num_top;
}

void Pizza::initToppings(int num_top)
{
	this->toppings = NULL;
	this->toppings = new Topping[num_top];
	assert(this->toppings);

}

void Pizza::copyToppings(int num_top, Topping* toppings)
{
	delete[] this->toppings; // delete previous value
	this->toppings = new Topping[num_top];
	for (int i = 0; i < num_top; i++)
	{
		this->toppings[i] = toppings[i];
	}
}

float Pizza::calcPrice() const
{
	float finalPrice = basePrice;


	for (int i = 0; i < num_top; i++)
	{
		finalPrice += toppings[i].getPrice();
	}
	return finalPrice;
}

Pizza& Pizza::operator=(const Pizza& other)
{
	setType(other.type);
	basePrice = other.basePrice;
	num_top = other.num_top;
	copyToppings(other.num_top, other.toppings);

	return *this;
}

std::ostream& operator<<(std::ostream& os, const Pizza& other)
{
	os << "type is: " << other.type << "\n";
	for (int i = 0; i < other.num_top; i++)
	{
		os << "toping "<<i+1<<" " <<other.toppings[i] << std::endl;
	}
	os << "\nFinal price is: " << other.calcPrice();
	return os;
}

void operator+(Pizza& one, const Topping& other)
{
	bool toppingAdded = false;
	for (int i = 0; (i < one.num_top) && (toppingAdded==false); i++)
	{
		if (one.toppings[i].getName() == NULL)
		{
			one.toppings[i] = other;
			toppingAdded = true;
		}
	}
	
}

bool operator==(const Pizza& one, const Pizza& other)
{
	if (one.num_top != other.num_top)
		return false;

	for (int i = 0; i < one.num_top; i++)
	{
		if (!(one.toppings[i] == other.toppings[i]))
			return false;
	}
	return true;
}
