//Dalya William 311529382 && Guy Rahamim Danino 313167686
package mainPackage;
import assignment4.*;

public class MainClass
	{

		public static void main(String[] args)
			{
				Book book = new Book("Generic book", 271, "Generic author");
				LibraryBook library = new LibraryBook("c-137", 200, "Bob",30);
				ComicBook comic = new ComicBook("The awakening",314,"Anthony russo",15);
				ActionComicBook wonderWoman = new ActionComicBook("Wonder Woman", 628,"William Moulton Marston, H. G. Peter",7,18);
				CookBook tasty = new CookBook("Tasty", 50, "Karin Goren",4,true);
				CosherCookBook joyOfCosher = new CosherCookBook("Joy of Cosher", 30,"Rabbi Akiva",5,false,"maimon");
				
				System.out.println("----------------------Calling borrow methods------------------------");
				System.out.println();
				library.borrow(30);
				comic.borrow(10);
				wonderWoman.borrow(5);
				tasty.borrow(7);
				joyOfCosher.borrow(55);
				
				System.out.println("\n\n------------------------calling returnBook methods------------------------");
				library.returnBook(50);
				comic.returnBook(314);
				wonderWoman.returnBook(1);
				tasty.returnBook(5);
				joyOfCosher.returnBook(271);
				
				System.out.println("\n\n------------------------calling toString methods------------------------");
				System.out.println(book);
				System.out.println(library);
				System.out.println(comic);
				System.out.println(wonderWoman);
				System.out.println(tasty);
				System.out.println(joyOfCosher);
				
				System.out.println("\n\n------------------------calling summarize methods------------------------");
				System.out.println(book.summarize());
				System.out.println(library.summarize());
				System.out.println(comic.summarize());
				System.out.println(wonderWoman.summarize());
				System.out.println(tasty.summarize());
				System.out.println(joyOfCosher.summarize());	
			}
	}
