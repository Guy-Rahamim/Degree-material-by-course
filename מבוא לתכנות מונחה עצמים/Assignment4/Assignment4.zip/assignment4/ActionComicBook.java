//Dalya William 311529382 && Guy Rahamim Danino 313167686
package assignment4;

public class ActionComicBook extends ComicBook
	{
		protected int recommendedReadingAge;
		
		public ActionComicBook()
		{
			super();
			setRecommendedReadingAge(16);
		}

		public ActionComicBook(String name, int numberOfPages, String author, int numberOfCopies, int recommendedReadingAge)
		{
			super (name,numberOfPages,author,numberOfCopies);
			setRecommendedReadingAge(recommendedReadingAge);
		}
	
		public int getRecommendedReadingAge()
			{
				return recommendedReadingAge;
			}

		public void setRecommendedReadingAge(int recommendedReadingAge)
			{
				if (recommendedReadingAge<1)
					{
						System.out.println("Recommended reading age cant be be under 1. setting to 16.");
						this.recommendedReadingAge=16;
					}
				else
					this.recommendedReadingAge = recommendedReadingAge;
			}
	
		@Override
		public boolean borrow(int copiesToBorrow)
		{
			if (copiesToBorrow<=getNumberOfCopies())
				{
					setNumberOfCopies(getNumberOfCopies()-copiesToBorrow);
					System.out.println("Borrow successful! Remaining copies of " +getClass().getSimpleName()+": " + getNumberOfCopies());
					return true;
				}
			else 
				{
					System.out.println("Sorry, there are not enough available copies right now.");
					return false;
				}
		}

		@Override
		public boolean returnBook(int amountToReturn)
		{
			if (amountToReturn<1)
				{
					System.out.println("you need to have "+getClass().getSimpleName()+"s in order to return them!");
					return false;
				}

			setNumberOfCopies(getNumberOfCopies()+amountToReturn);
			System.out.println(getClass().getSimpleName()+" Return successful! number of available copies:"+ getNumberOfCopies());
			return true;
		}
		@Override
		public String summarize()
		{
			return "This " +getClass().getSimpleName()+ " is for ages greater than " + getRecommendedReadingAge();
		}
		
		@Override
		public String toString()
		{
			return super.toString() + ", Recommended reading age: " +getRecommendedReadingAge();
		}
	
		@Override
		public boolean equals(Object obj)
		{
			//are both objects referencing the same memory address?
			if(this==obj)
				return true;
			if (!super.equals(obj))
				return false;
			
			ActionComicBook other = (ActionComicBook) obj;
			
			if (this.getRecommendedReadingAge()!=other.getRecommendedReadingAge())
				return false;
			return true;
		}

	}
