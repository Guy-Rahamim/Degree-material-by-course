//Dalya William 311529382 && Guy Rahamim Danino 313167686
package assignment4;

public class LibraryBook extends Book
	{
		protected int numberOfCopies;
		public LibraryBook()
		{
			super();
			setNumberOfCopies(10);
		}
		
		public LibraryBook(String name, int numberOfPages, String author,int numberOfCopies)
		{
			super(name,numberOfPages,author);
			setNumberOfCopies(numberOfCopies);
		} 
		
		public int getNumberOfCopies()
			{
				return numberOfCopies;
			}

		public void setNumberOfCopies(int numberOfCopies)
			{
				if(numberOfCopies<0)
					{
						System.out.println("Number of copies cant be less than 0! setting to 1.");
						this.numberOfCopies=1;
					}
				else
					this.numberOfCopies = numberOfCopies;
			}


		
		@Override
		public String summarize()
		{
			return super.summarize()+" This book is for reading inside the library only!";
		}
		
		public boolean borrow(int copiesToBorrow)
		{
			System.out.println("Sorry, a " +getClass().getSimpleName() + " cannot be borrowed. Borrow failed.");
			return false;
		}
		
		public boolean returnBook (int copiesToReturn)
					{
						System.out.println("You cant return a "+ getClass().getSimpleName()+" because you cant borrow it! return failed.");
						return false;
					}
	}
