//Dalya William 311529382 && Guy Rahamim Danino 313167686
package assignment4;

public class CookBook extends LibraryBook
	{
		protected int numberOfCopies;
		protected boolean isDamaged;
		
		public CookBook()
		{
			super();
			setNumberOfCopies(10);
			setIsDamaged(false);
		}
		
		public CookBook(String name, int numberOfPages, String author, int numberOfCopies, boolean isDamaged)
		{
			super(name, numberOfPages, author,numberOfCopies);
			setIsDamaged(isDamaged);
		}
		
	
		public boolean getIsDamaged()
			{
				return isDamaged;
			}

		public void setIsDamaged(boolean isDamaged)
			{
				this.isDamaged = isDamaged;
			}

		public String toString()
		{
			String isDamagedString;
			if (isDamaged)
				isDamagedString = "the book is damaged.";
			else
				isDamagedString = "the book is intact!";
			return super.toString() + ", number of available copies: " +numberOfCopies + " ," +isDamagedString;
		}

		@Override
		public boolean borrow(int copiesToBorrow)
		{
			if (copiesToBorrow<=getNumberOfCopies())
				{
					setNumberOfCopies(getNumberOfCopies()-copiesToBorrow);
					System.out.println("Borrow successful! Remaining copies of " +getClass().getSimpleName()+": " + getNumberOfCopies());
					return true;
				}
			else 
				{
					System.out.println("Sorry, there are not enough available copies of " +getClass().getSimpleName()+"  right now.");
					return false;
				}
		}
		
		@Override
		public boolean returnBook(int amountToReturn)
		{
			if (amountToReturn<1)
				{
					System.out.println("you need to have books in order to return them!");
					return false;
				}
			if (isDamaged)
				{
					fine();
				}
			setNumberOfCopies(getNumberOfCopies()+amountToReturn);
			System.out.println(getClass().getSimpleName()+" Return successful! number of available copies:"+ getNumberOfCopies());
			return true;
		}

		public void fine()
		{
			System.out.println("One of the " +getClass().getSimpleName()+"s you returned is damaged!\nfine is 200NIS.");
		}

		@Override
		public String summarize()
		{
			return "This "+ getClass().getSimpleName()+" might contain non cosher ingredients";
		}
		
		@Override
		public boolean equals(Object obj)
		{
			//are both objects referencing the same memory address?
			if (this==obj)
				return true;
			//comparing shared super fields
			if (!super.equals(obj))
				return false;
			
			//casting Object to CookBook
			CookBook other = (CookBook) obj;
			
			//checking values for non shared fields
			if (this.getIsDamaged()!=other.getIsDamaged())
				return false;
			return true;
		}

	}
