//Dalya William 311529382 && Guy Rahamim Danino 313167686
package assignment4;

public class CosherCookBook extends CookBook
	{
		protected String supervision;
		
		public CosherCookBook()
		{
			super();
			setSupervision("the almighty flying spaggheti moster!");
		}
		
		public CosherCookBook(String name, int numberOfPages, String author, int numberOfAvailableBooks, boolean isDamaged, String supervision)
		{
			super(name, numberOfPages, author, numberOfAvailableBooks, isDamaged);
			setSupervision(supervision);
		}

		public String getSupervision()
			{
				return supervision;
			}

		public void setSupervision(String supervision)
			{
				this.supervision = supervision;
			}

		@Override
		public String summarize()
		{
			return "this " + getClass().getSimpleName()+"is supervised by " + supervision;
		}
		
		@Override
		public boolean equals(Object obj)
		{
			//are both objects referencing the same memory address?
			if (this==obj)
				return true;
			
			//checking the shared fields with super.
			if (!super.equals(obj))
				return false;
			
			//casting to CosherCookBook
			CosherCookBook other = (CosherCookBook) obj;
			
			//checking for non shared fields.
			if (this.getSupervision()!=other.getSupervision())
				return false;
			return true;
		}
	}
