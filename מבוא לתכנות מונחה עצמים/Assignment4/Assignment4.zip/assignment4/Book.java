//Dalya William 311529382 && Guy Rahamim Danino 313167686
package assignment4;

public class Book
	{
		protected String name;
		protected int numberOfPages;
		protected String author;
		
		public Book()
		{
			setName("Generic " + getClass().getSimpleName());
			setNumberOfPages(100);
			setAuthor("Generic author");
		}
		
		public Book(String name, int numberOfPages, String author)
		{
			setName(name);
			setNumberOfPages(numberOfPages);
			setAuthor(author);
		}

		public String getName()
			{
				return name;
			}

		public void setName(String name)
			{
				this.name = name;
			}

		public int getNumberOfPages()
			{
				return numberOfPages;
			}

		public void setNumberOfPages(int numberOfPages)
			{
				if (numberOfPages<=0)
					{
						System.out.println("a book cant have fewer than 1 pages. setting number of pages to 100.");
						this.numberOfPages=100;
					}
				else
				this.numberOfPages = numberOfPages;
			}

		public String getAuthor()
			{
				return author;
			}

		public void setAuthor(String author)
			{
				this.author = author;
			}
	
		public String summarize()
		{
			return "This is a " + getClass().getSimpleName()+".";
		}
		
		@Override
		public boolean equals(Object obj)
		{
			//is obj referencing a memory address?
			if (obj==null)
				return false;
			
			//are both objects referenceing the same address?
			if (this==obj)
				return true;
			
			//are both objects instantiated by the same class?
			if (this.getClass()!=obj.getClass())
				return false;
			
			//taking the reference held by obj and casting it to a Book type object.
			Book other = (Book) obj;
			if (this.getName()!=other.getName())
				return false;
			
			//checking each individual field of class Book.
			if (this.getNumberOfPages()!=other.getNumberOfPages())
				return false;
			
			if (this.getAuthor()!=other.getAuthor())
				return false;
			
			//if we managed to get this far, the objects must be equal in value.
			return true;
		}

		public String toString()
		{
			return getClass().getSimpleName()+" name: " +getName() + ", number of pages: " + getNumberOfPages()+ ", Author: " + getAuthor();
		}
	}
	
