//Dalya William 311529382 && Guy Rahamim Danino 313167686
package assignment4;

public class ComicBook extends LibraryBook
	{
		
		public ComicBook()
		{
			super();
		}
		
		public ComicBook(String name, int numberOfPages, String authorName, int numberOfCopies)
		{
			super(name,numberOfPages,authorName,numberOfCopies);
		}
		
		public int getNumberOfCopies()
		{
			return numberOfCopies;
		}
		
		public void setNumberOfCopies(int numberOfAvailableCopies)
		{
			if (numberOfAvailableCopies<0)
				{
					System.out.println("Minumum number of available copies is 0. Setting the number to 1.");
					this.numberOfCopies=1;
				}
			this.numberOfCopies=numberOfAvailableCopies;
		}
		
		@Override
		public String summarize()
		{
			return "This is a generic " +getClass().getSimpleName() +". This is for reading inside the library only!";
		}
	
		@Override
		public boolean equals(Object obj)
		{
			//are both objects referencing the same memory address?
			if (this==obj)
				return true;
			
			//checking for shared fields with super.
			if (!super.equals(obj))
				return false; 
			
				ComicBook other = (ComicBook) obj; //casting obj to ComicBook
			
				if (this.getNumberOfCopies()!=other.getNumberOfCopies())
					return false;
				return true;
				
		}
	
	
	
	}
