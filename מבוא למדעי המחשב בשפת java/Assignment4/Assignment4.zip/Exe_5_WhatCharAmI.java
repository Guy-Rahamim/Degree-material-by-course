//Dalya William & Guy Rahamim
//Assignment 5
import java.util.Scanner;
public class Exe_5_WhatCharAmI
	{
		public static void main(String[] args)
		{		
			//initializing variables
			Scanner input= new Scanner (System.in);
			char userChar;
			final char  DIGIT_MIN_LIMIT='0',
						DIGIT_MAX_LIMIT='9',
						LOWER_CASE_MIN_LIMIT='a',
						LOWER_CASE_MAX_LIMIT='z',
						UPPER_CASE_MIN_LIMIT='A',
						UPPER_CASE_MAX_LIMIT='Z';
	
			//asking the user to input a single character
			System.out.println("Please enter a single character: ");
			userChar= input.next().charAt(0);
	
			
			//if the character is not a digit or either type of letter, print other.
			if (userChar < DIGIT_MIN_LIMIT || (DIGIT_MAX_LIMIT < userChar && userChar <UPPER_CASE_MIN_LIMIT))
				{ System.out.println("Other!"); }
	
			//else, if the character is a digit, print Digit.
			else if (DIGIT_MIN_LIMIT <= userChar && userChar <= DIGIT_MAX_LIMIT)
				{ System.out.println("Digit!"); }
	
			//else, if the character is a lower case letter, print LowerCase.
			else if (LOWER_CASE_MIN_LIMIT <=userChar && userChar<=LOWER_CASE_MAX_LIMIT)
				{System.out.println("LowerCase!");}
			
			//else, if the character is an Max case letter, print MaxCase.
			else if (UPPER_CASE_MIN_LIMIT <=userChar && userChar <=UPPER_CASE_MAX_LIMIT)
				{System.out.println("UpperCase!");}
		
			input.close();
			}
}