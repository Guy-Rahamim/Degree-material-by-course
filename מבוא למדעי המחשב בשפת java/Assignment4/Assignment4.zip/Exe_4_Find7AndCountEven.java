//Dalya William & Guy Rahamim
//Assignment 4
import java.util.Scanner;
public class Exe_4_Find7AndCountEven
	{
		public static void main(String[] args)
		{
			//initializing variables.
			Scanner input = new Scanner (System.in);
			int num, evenCounter=0;
			 
			do //while loop's body.
			{
				//taking a number from the user and checks if its even.
				//if it is, increase evenCounter by 1.
				//this is executed continuously (while loop) until 7 is entered.
				System.out.println("Please enter a number:");
				num=input.nextInt();
				if (num%2==0)	{ evenCounter++; }
			}
			while (num!=7); //while loop condition.
			
			//print evenCounter.
			System.out.println("Number of even numbers entered: " + evenCounter);
				input.close();
		}
}
