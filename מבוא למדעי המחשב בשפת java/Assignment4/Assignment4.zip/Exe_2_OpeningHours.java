//Dalya William & Guy Rahamim
//Assignment 2
import java.util.Scanner;
public class Exe_2_OpeningHours
	{
		public static void main(String[] args)
		{
			//initializing variables.
			Scanner input = new Scanner (System.in);
			int day=0, visitHour, monday=2,
					openingTime=10, closingTime=13;
			
			//taking the day of the users visit to the store
			System.out.println("Please enter the day of your visit: ");
			day = input.nextInt();
			
			//if its not monday, print "we're closed!"
			if (day!=monday) 
				{ System.out.println("Sorry, we're closed!"); }
			
			else //but if it is monday:
				{
				//take the users time of arrival.
				System.out.println("Please enter the time of your visit: ");
				visitHour = input.nextInt();
						
				//if the visit hour is when the shop is open
				if (openingTime<=visitHour && visitHour <= closingTime)
					{ System.out.println("Come in, we're open!"); }
				else {System.out.println("Sorry, we're closed!");}
				}
			input.close();
			}
	}
