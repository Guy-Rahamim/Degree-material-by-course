//Dalya William & Guy Rahamim
//Assignment 1
import java.util.Scanner;
public class Exe_1_TheInvestor
	{
		public static void main(String[] args)
		{
			//initializing variables.
			Scanner input = new Scanner(System.in);
			float oldPrice, newPrice;
			
			//ask the user for the old stock price.
			System.out.println("Please enter the old stock price: ");
			oldPrice=input.nextFloat();
			
			//ask the user for the new stock price.
			System.out.println("Please enter the new stock price: ");
			newPrice=input.nextFloat();
			
			//if new price is bigger or equal to the old price
			if (newPrice >= oldPrice)
			{
					//print BUY and the difference of new from old.
					System.out.println( "BUY!");
					System.out.println("the price difference is :" + (newPrice-oldPrice));
			}
			else //if not
				{
					//print SELL and the difference of old from new.
					System.out.println("SELL!");
					System.out.println("the price difference is: " + (oldPrice-newPrice));
				}		
			input.close();
		}	
	}
