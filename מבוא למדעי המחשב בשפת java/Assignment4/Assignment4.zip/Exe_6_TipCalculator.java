//Dalya William & Guy Rahamim
//Assignment 6
import java.util.Scanner;
public class Exe_6_TipCalculator
	{
		public static void main(String[] args)
		{
			//initializing variables.
			Scanner input = new Scanner(System.in);
			float mealPrice, priceIncludingTip=0,
				tipMe10=0.10f,
				tipMe12=0.12f,
				tipMe15=0.15f,
				tipMe20=0.20f;
				int tipAmount;
				
			//taking the price of the users meal.
			System.out.print("Please enter the price of you meal: ");
			mealPrice=input.nextFloat();
			
			//taking the user tip percentage.
			System.out.println("\n Please choose your preferred tip amount in %: ");
			System.out.println("Tipping options are: 10%, 12%, 15%, 20%");
			tipAmount=input.nextInt();
			
			switch(tipAmount)
			{
				case (10):
				{
					//if user chose 10, add 10% to meal price.
					priceIncludingTip=mealPrice+(mealPrice*tipMe10);
					break;
				}
				
				case (12):
				{
					//if user chose 12, add 12% to meal price.
					priceIncludingTip=mealPrice+(mealPrice*tipMe12);
					break;
				}
				
				case (15):
				{
					//if user chose 15, add 15% to meal price.
					priceIncludingTip=mealPrice+(mealPrice*tipMe15);
					break;
				}
				
				case (20):	
				{
					//if user chose 20, add 20% to meal price.
					priceIncludingTip=mealPrice+(mealPrice*tipMe20);
					break;
				}
			}
			//print the final meal price, including the chosen tip.
			System.out.println("The price of your meal including tip is: " + priceIncludingTip);
			input.close();
		}
}