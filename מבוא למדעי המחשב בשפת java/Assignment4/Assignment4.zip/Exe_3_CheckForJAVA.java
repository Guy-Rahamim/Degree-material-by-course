//Dalya William & Guy Rahamim
//Assignment 3
import java.util.Scanner;
public class Exe_3_CheckForJAVA
	{
		public static void main(String[] args)
		{
			//initializing variables
			Scanner input = new Scanner(System.in);
			char checker;
			
			//take a  single character from the user.
			System.out.println("Please enter a letter:");
			checker=input.next().charAt(0);
			
			
			//checks if the letter is either A, J or V and prints "Valid".
			switch (checker)
			{
				case 'A':
					
				case 'J':
					
				case 'V':
					System.out.println("Valid");
					break;
					
					//if none of the above, print "Invalid".
					default:
						System.out.println("Invalid input!");
		
			}
		input.close();
		}
	}
