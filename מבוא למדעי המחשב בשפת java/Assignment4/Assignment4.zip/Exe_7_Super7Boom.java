//Dalya William & Guy Rahamim
//Assignment 7
import java.util.Scanner;
public class Exe_7_Super7Boom
	{
		public static void main(String[] args)
		{
			//initializing input.
			Scanner input= new Scanner (System.in);
			int outerCounter=1, innerCounter=1, digit;
			char digitBottomLimit=0, digitUpperLimit=9;
			
			// a do while loop that repeats as long as the input
			// is not a single digit.
			
			System.out.println("Please enter a single digit.");
			digit=input.nextInt();
			
			while (digit<=digitBottomLimit || digit > digitUpperLimit)
				{
					//while the input is not a digit
					//print bad input and ask for a new entry.
					System.out.println("Bad input! Please enter a single digit.");
					digit=input.nextInt();
				}

			//the outer counter repeats 100 times.
			while (outerCounter<=100)
				{
					//the inner while loop repeats 10 times per cycle, for 10 cycles.
					while (innerCounter<=10)
						{
							//if the outer counter % digit = 0, print BOOM.
							if (outerCounter%digit==0)
								System.out.print("BOOM ,  ");
							else //if not, print the current value of outer counter and a comma.
								System.out.print("  " + outerCounter + "  ,    ");
							//increase both counters by 1.
							outerCounter++;
							innerCounter++;
						}
					System.out.println("");
					//set inner counter back to 1 so the 
					//inner while loop can start over.
					innerCounter=1;
				}
		input.close();
	}
}