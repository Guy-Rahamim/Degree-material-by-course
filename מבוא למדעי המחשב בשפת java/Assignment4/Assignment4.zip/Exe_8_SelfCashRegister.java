//Dalya William & Guy Rahamim
//Assignment 8
import java.util.Scanner;
public class Exe_8_SelfCashRegister
{
	public static void main(String[] args)
	{
		//initializing variables.
		Scanner input = new Scanner (System.in);
		float 	totalPrice=0.f,
				currentPrice=0.f,
				bambaPrice=3.9f,
				cokePrice=4.5f,
				bubblegumPrice=1.5f,
				icecreamPrice=8.0f;
		char addRemoveOrSum='0', productSelection;
		
		//boolean that stores if '=' was entered mid loop
		boolean suddenCheckout=false; 
	
		System.out.println("Welcome to our shop!");
		
		//A while loop asks for a product and an 
		//action (+,-). then calculates
		//total price when user enters =.
		while (addRemoveOrSum!='=')
		{
		//	suddenCheckout=false;
		System.out.println("Please Choose a product from the following:"
				+ "\n 1.Bamba: 3.9 NIS"
				+ "\n 2.Coke: 4.5 NIS "
				+ "\n 3.Bubblegum: 1.5 NIS"
				+ "\n 4.Icecream: 8 NIS"
				+ "\n \n at any stage, press (=) to check out");
		productSelection=input.next().charAt(0);
		if (productSelection >='1' && productSelection <= '4'|| productSelection=='=' )
			{			
		//switch statement that chooses a product.
		switch (productSelection)
		{
			case '1':
			{
				System.out.println("You chose bamba");
				currentPrice=bambaPrice;
				break;
			}
			
			case '2':
			{
				System.out.println("You chose coke");
				currentPrice=cokePrice;
				break;
			}
			
			case '3':
			{
				System.out.println("You chose bubble gum");
				currentPrice=bubblegumPrice;
				break;
			}
			
			case '4':
				{
				System.out.println("You chose ice cream");
				currentPrice = icecreamPrice;
					break;
			}
			
			case '=':
			{ suddenCheckout=true; }
			
		}
		
		// if user entered = when choosing a product,
		//break out of the loop.
			if (suddenCheckout==true) 				
				break;
			
		//asking the user whether to add or remove a product
		System.out.println("do you want to add the product (+) or remove it (-)?");
		addRemoveOrSum=input.next().charAt(0);
			
			switch (addRemoveOrSum)
			{
				case '+':
					{
						totalPrice += currentPrice; 
						System.out.println("Product added!");
						break;
					}
				
				case '-':
				{
					totalPrice-=currentPrice; 
					System.out.println("Product removed!");
					break;
				}
				case '=':
				{ suddenCheckout=true; }
			}
			
				// if user entered '=' when choosing a product,
				//break out of the loop.
			if (!suddenCheckout) 
				{
			System.out.println("Would you like to check out?"
					+ "\n if yes, enter =. if not, press any key. \n");
			
			addRemoveOrSum=input.next().charAt(0);
			currentPrice=0;	//reset currentPrice until it receives a new value.
				}
			}
		else System.out.println("bad input! please choose a number from 1 to 4");
			}
		//as long as the user hasn't typed "=", enter the loop again.
			System.out.println("The total price of your purchase is: " + totalPrice);
			input.close();
	}
}